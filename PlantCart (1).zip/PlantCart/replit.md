# Paradise Nursery Shopping Application

## Overview

Paradise Nursery is a full-stack e-commerce web application for an online plant store specializing in aromatic and medicinal indoor plants. The application provides a complete shopping cart experience with product browsing, category filtering, cart management, and a responsive user interface. Built as a React-based single-page application with an Express.js backend, it demonstrates modern web development practices including state management, API integration, and component-based architecture.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### Final Project Completion (January 16, 2025)
- ✓ Updated all 8 plant images with specific, real images from specialized websites:
  - Albahaca Fresca: Leonardita Iberia
  - Lavanda: Falcon Agroalimentaria  
  - Romero: diet-health.info
  - Menta: AD Magazine
  - Aloe Vera: CuidatePlus
  - Manzanilla: Mama Bruja
  - Eucalipto: El Universo
  - Caléndula: Sembramos
- ✓ Fixed About page image (greenhouse image)
- ✓ Converted to frontend-only application for GitHub Pages compatibility
- ✓ Application ready for final course submission (50 points)

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: Redux Toolkit for global cart state management with local component state using React hooks
- **UI Components**: Shadcn/ui component library built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for consistent theming
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Server Framework**: Express.js with TypeScript for API endpoints and middleware
- **Data Layer**: In-memory storage implementation with interface-based design for easy database integration
- **API Design**: RESTful endpoints for plants and cart operations with proper HTTP status codes
- **Validation**: Zod schemas for request/response validation and type safety
- **Development**: Hot module replacement and error overlay for enhanced developer experience

### State Management Strategy
- **Global State**: Redux store manages cart items, quantities, and totals across components
- **Local State**: React hooks (useState, useEffect) for component-specific state like loading states and form inputs
- **Server State**: TanStack Query for API data fetching, caching, and synchronization
- **Form State**: React Hook Form with Zod resolvers for form validation and submission

### Component Design Patterns
- **Composition**: Reusable UI components with props-based customization
- **Container/Presentational**: Clear separation between business logic and presentation
- **Compound Components**: Complex UI patterns using multiple related components
- **Custom Hooks**: Shared logic extraction for mobile detection and toast notifications

### Data Flow Architecture
- **Unidirectional Data Flow**: Props down, events up pattern with Redux for cross-component communication
- **API Integration**: Centralized query client configuration with error handling and retry logic
- **Real-time Updates**: Optimistic updates for cart operations with rollback on failure
- **Type Safety**: End-to-end TypeScript with shared schemas between frontend and backend

## External Dependencies

### Database and Storage
- **Database**: PostgreSQL configured via Drizzle ORM with migration support
- **Connection**: Neon Database serverless PostgreSQL for production deployment
- **Schema Management**: Drizzle Kit for database migrations and schema evolution
- **Development Storage**: In-memory storage implementation for rapid prototyping

### UI and Design System
- **Component Library**: Radix UI primitives for accessible, unstyled components
- **Icons**: Lucide React for consistent iconography throughout the application
- **Styling Framework**: Tailwind CSS with PostCSS for utility-first styling
- **Fonts**: Google Fonts integration with multiple font families for typography hierarchy

### Development and Build Tools
- **Package Manager**: npm with lock file for consistent dependency resolution
- **TypeScript**: Strict type checking with path mapping for clean imports
- **Linting and Formatting**: ESLint and Prettier integration for code quality
- **Development Server**: Vite dev server with HMR and error overlay plugins

### Third-Party Services
- **Image Hosting**: Unsplash for high-quality plant photography with responsive image loading
- **Deployment Platform**: Replit-specific configurations and plugins for seamless hosting
- **Session Management**: Express session with PostgreSQL store for user session persistence
- **Error Tracking**: Development error modal for enhanced debugging experience