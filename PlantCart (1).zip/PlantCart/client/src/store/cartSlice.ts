import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { Plant } from '@shared/schema';

interface CartItem {
  id: string;
  plant: Plant;
  quantity: number;
}

interface CartState {
  items: CartItem[];
  totalItems: number;
  totalCost: number;
}

const initialState: CartState = {
  items: [],
  totalItems: 0,
  totalCost: 0,
};

const calculateTotals = (items: CartItem[]) => {
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalCost = items.reduce((sum, item) => sum + (parseFloat(item.plant.price) * item.quantity), 0);
  return { totalItems, totalCost };
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action: PayloadAction<{ plant: Plant; quantity?: number }>) => {
      const { plant, quantity = 1 } = action.payload;
      const existingItem = state.items.find(item => item.plant.id === plant.id);
      
      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        state.items.push({
          id: `cart-${plant.id}-${Date.now()}`,
          plant,
          quantity,
        });
      }
      
      const totals = calculateTotals(state.items);
      state.totalItems = totals.totalItems;
      state.totalCost = totals.totalCost;
    },
    removeFromCart: (state, action: PayloadAction<string>) => {
      state.items = state.items.filter(item => item.id !== action.payload);
      
      const totals = calculateTotals(state.items);
      state.totalItems = totals.totalItems;
      state.totalCost = totals.totalCost;
    },
    updateQuantity: (state, action: PayloadAction<{ id: string; quantity: number }>) => {
      const { id, quantity } = action.payload;
      const item = state.items.find(item => item.id === id);
      
      if (item && quantity > 0) {
        item.quantity = quantity;
      } else if (item && quantity <= 0) {
        state.items = state.items.filter(item => item.id !== id);
      }
      
      const totals = calculateTotals(state.items);
      state.totalItems = totals.totalItems;
      state.totalCost = totals.totalCost;
    },
    clearCart: (state) => {
      state.items = [];
      state.totalItems = 0;
      state.totalCost = 0;
    },
  },
});

export const { addToCart, removeFromCart, updateQuantity, clearCart } = cartSlice.actions;
export default cartSlice.reducer;
