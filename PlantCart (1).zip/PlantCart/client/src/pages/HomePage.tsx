import { Link } from "wouter";
import { ArrowRight, Sprout, Truck, Heart } from "lucide-react";

export default function HomePage() {
  return (
    <div id="home-page">
      {/* Hero Section */}
      <section className="relative h-96 md:h-[500px] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-forest/80 to-sage/60"></div>
        <div 
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')",
            backgroundSize: "cover",
            backgroundPosition: "center"
          }}
          className="absolute inset-0"
        ></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white max-w-2xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Transforma tu hogar con
              <span className="text-sand"> plantas naturales</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-100">
              Descubre nuestra colección de plantas de interior aromáticas y medicinales
            </p>
            <Link href="/products">
              <button className="bg-sand hover:bg-orange-500 text-white font-semibold py-4 px-8 rounded-lg text-lg transition-colors duration-200 shadow-lg">
                Explorar Plantas
                <ArrowRight className="inline ml-2 h-5 w-5" />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Por qué elegir Paradise Nursery?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ofrecemos las mejores plantas para tu hogar con garantía de calidad y cuidados especializados
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-forest/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sprout className="text-forest text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Plantas Frescas</h3>
              <p className="text-gray-600">
                Plantas cultivadas con cuidado y seleccionadas por su calidad superior
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-sage/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="text-sage text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Envío Seguro</h3>
              <p className="text-gray-600">
                Empaque especializado para garantizar que tus plantas lleguen perfectas
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-sand/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="text-sand text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Soporte Experto</h3>
              <p className="text-gray-600">
                Consejos de cuidado y asesoramiento personalizado para cada planta
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
