import { useState } from "react";
import { Leaf, Plus } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import { aromaticPlants, medicinalPlants } from "@/data/plants";

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const plants = [...aromaticPlants, ...medicinalPlants];

  const getFilteredPlants = () => {
    switch (selectedCategory) {
      case "aromatic":
        return aromaticPlants;
      case "medicinal":
        return medicinalPlants;
      default:
        return plants;
    }
  };



  return (
    <div id="products-page">
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Nuestras Plantas</h2>
            <p className="text-xl text-gray-600">Encuentra la planta perfecta para tu espacio</p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-6 py-3 rounded-full font-medium transition-colors duration-200 ${
                selectedCategory === "all"
                  ? "bg-forest text-white"
                  : "bg-white text-forest border border-forest hover:bg-forest hover:text-white"
              }`}
            >
              Todas las Plantas
            </button>
            <button
              onClick={() => setSelectedCategory("aromatic")}
              className={`px-6 py-3 rounded-full font-medium transition-colors duration-200 ${
                selectedCategory === "aromatic"
                  ? "bg-forest text-white"
                  : "bg-white text-forest border border-forest hover:bg-forest hover:text-white"
              }`}
            >
              Plantas Aromáticas
            </button>
            <button
              onClick={() => setSelectedCategory("medicinal")}
              className={`px-6 py-3 rounded-full font-medium transition-colors duration-200 ${
                selectedCategory === "medicinal"
                  ? "bg-forest text-white"
                  : "bg-white text-forest border border-forest hover:bg-forest hover:text-white"
              }`}
            >
              Plantas Medicinales
            </button>
          </div>

          {/* Show sections only when "all" is selected */}
          {selectedCategory === "all" && (
            <>
              <div className="mb-16">
                <h3 className="text-2xl font-bold text-forest mb-8 flex items-center">
                  <Leaf className="mr-3" />
                  Plantas Aromáticas
                </h3>
                
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {aromaticPlants.map((plant) => (
                    <ProductCard key={plant.id} plant={plant} />
                  ))}
                </div>
              </div>

              <div className="mb-16">
                <h3 className="text-2xl font-bold text-forest mb-8 flex items-center">
                  <Plus className="mr-3" />
                  Plantas Medicinales
                </h3>
                
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {medicinalPlants.map((plant) => (
                    <ProductCard key={plant.id} plant={plant} />
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Filtered Results */}
          {selectedCategory !== "all" && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {getFilteredPlants().map((plant) => (
                <ProductCard key={plant.id} plant={plant} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
