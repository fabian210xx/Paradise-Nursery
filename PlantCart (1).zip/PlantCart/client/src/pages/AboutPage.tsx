import { Leaf, Heart, Users, Award, Shield, Truck } from "lucide-react";

export default function AboutPage() {
  return (
    <div id="about-page">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-forest/10 to-sage/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Sobre Paradise Nursery
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Somos especialistas en plantas de interior aromáticas y medicinales, 
            comprometidos con traer la naturaleza a tu hogar con la más alta calidad.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Nuestra Misión</h2>
              <p className="text-lg text-gray-600 mb-6">
                En Paradise Nursery creemos que cada hogar merece el poder curativo y aromático 
                de las plantas naturales. Nos especializamos en cultivar y seleccionar las mejores 
                plantas de interior con propiedades terapéuticas y aromáticas.
              </p>
              <p className="text-lg text-gray-600">
                Nuestro objetivo es hacer que el cuidado de plantas sea accesible para todos, 
                proporcionando plantas de calidad superior junto con el conocimiento necesario 
                para su cuidado exitoso.
              </p>
            </div>
            <div className="text-center">
              <img 
                src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="Invernadero Paradise Nursery" 
                className="rounded-lg shadow-lg w-full h-80 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestros Valores</h2>
            <p className="text-xl text-gray-600">Los principios que guían nuestro trabajo diario</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center bg-white p-8 rounded-xl shadow-sm">
              <div className="w-16 h-16 bg-forest/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="text-forest text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Calidad Natural</h3>
              <p className="text-gray-600">
                Cultivamos nuestras plantas sin químicos dañinos, usando métodos orgánicos 
                que preservan sus propiedades naturales.
              </p>
            </div>
            
            <div className="text-center bg-white p-8 rounded-xl shadow-sm">
              <div className="w-16 h-16 bg-sage/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="text-sage text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Cuidado Personal</h3>
              <p className="text-gray-600">
                Cada planta recibe atención individual y viene con instrucciones detalladas 
                de cuidado personalizado.
              </p>
            </div>
            
            <div className="text-center bg-white p-8 rounded-xl shadow-sm">
              <div className="w-16 h-16 bg-sand/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-sand text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Comunidad</h3>
              <p className="text-gray-600">
                Construimos una comunidad de amantes de las plantas, compartiendo conocimiento 
                y experiencias.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1 text-center">
              <img 
                src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="Invernadero Paradise Nursery" 
                className="rounded-lg shadow-lg w-full h-80 object-cover"
              />
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Nuestra Historia</h2>
              <p className="text-lg text-gray-600 mb-6">
                Paradise Nursery nació de la pasión por las plantas medicinales y aromáticas. 
                Fundada en 2020, comenzamos como un pequeño invernadero familiar con el sueño 
                de compartir los beneficios de las plantas naturales.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Hoy, somos reconocidos por nuestra expertise en plantas de interior con propiedades 
                terapéuticas. Cada planta en nuestro catálogo ha sido cuidadosamente seleccionada 
                por sus beneficios únicos y facilidad de cuidado.
              </p>
              <div className="flex items-center space-x-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-forest">2000+</div>
                  <div className="text-sm text-gray-600">Plantas vendidas</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-forest">500+</div>
                  <div className="text-sm text-gray-600">Clientes felices</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-forest">4</div>
                  <div className="text-sm text-gray-600">Años de experiencia</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Guarantees Section */}
      <section className="py-16 bg-forest text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Nuestras Garantías</h2>
            <p className="text-xl opacity-90">Comprometidos con tu satisfacción</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Calidad Garantizada</h3>
              <p className="opacity-90">
                Garantizamos la calidad de nuestras plantas. Si no estás satisfecho, 
                te devolvemos tu dinero.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Envío Seguro</h3>
              <p className="opacity-90">
                Empaque especializado que protege tus plantas durante el transporte. 
                Llegada en perfecto estado garantizada.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Soporte Experto</h3>
              <p className="opacity-90">
                Asesoramiento gratuito para el cuidado de tus plantas. Nuestros expertos 
                están aquí para ayudarte.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}