import { Link } from "wouter";
import { useSelector } from "react-redux";
import { ShoppingCart, ArrowLeft, ArrowRight } from "lucide-react";
import type { RootState } from "@/store/store";
import CartItem from "@/components/CartItem";

export default function CartPage() {
  const { items, totalCost } = useSelector((state: RootState) => state.cart);

  if (items.length === 0) {
    return (
      <section className="py-16 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-sm p-8">
            <div className="text-center py-12">
              <ShoppingCart className="mx-auto text-6xl text-gray-300 mb-4 h-24 w-24" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Tu carrito está vacío</h3>
              <p className="text-gray-600 mb-6">¿Por qué no agregas algunas plantas hermosas?</p>
              <Link href="/products">
                <button className="bg-forest hover:bg-green-800 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200">
                  Explorar Plantas
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <div id="cart-page">
      <section className="py-16 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-sm p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 flex items-center">
              <ShoppingCart className="mr-3 text-forest" />
              Tu Carrito de Compras
            </h2>

            <div className="space-y-6 mb-8">
              {items.map((item) => (
                <CartItem
                  key={item.id}
                  id={item.id}
                  plant={item.plant}
                  quantity={item.quantity}
                />
              ))}
            </div>

            {/* Cart Summary */}
            <div className="border-t border-gray-200 pt-8">
              <div className="flex justify-between items-center mb-6">
                <span className="text-xl font-semibold text-gray-900">Total del Carrito:</span>
                <span className="text-3xl font-bold text-forest">${totalCost.toFixed(2)}</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/products" className="flex-1">
                  <button className="w-full bg-white border border-gray-300 text-gray-700 font-medium py-3 px-6 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <ArrowLeft className="mr-2 h-5 w-5 inline" />
                    Continuar Comprando
                  </button>
                </Link>
                <button className="flex-1 bg-forest hover:bg-green-800 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200">
                  Proceder al Pago
                  <ArrowRight className="ml-2 h-5 w-5 inline" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
