import type { Plant } from '@shared/schema';

export const aromaticPlants: Plant[] = [
  {
    id: "1",
    name: "Albahaca Fresca",
    description: "Perfecta para cocinar y aromática. Fácil de cuidar en interiores.",
    price: "15.99",
    category: "aromatic",
    imageUrl: "https://leonarditaiberia.com/wp-content/uploads/2021/01/Albahaca.jpg"
  },
  {
    id: "2",
    name: "Lavanda",
    description: "Aromática y relajante. Ideal para dormitorios y espacios de relajación.",
    price: "22.50",
    category: "aromatic",
    imageUrl: "https://falconagroalimentaria.com/wp-content/uploads/2025/03/comprar-lavanda-natural.webp"
  },
  {
    id: "3",
    name: "Romero",
    description: "Aromático y culinario. Excelente para la cocina y fácil de mantener.",
    price: "18.75",
    category: "aromatic",
    imageUrl: "https://www.diet-health.info/images/recipes/700/1280px-rosemary-7560.jpg"
  },
  {
    id: "4",
    name: "Menta",
    description: "Refrescante y aromática. Perfecta para tés e infusiones caseras.",
    price: "12.99",
    category: "aromatic",
    imageUrl: "https://media.admagazine.com/photos/618a61cc51ab72df0a764124/master/pass/83664.jpg"
  },
];

export const medicinalPlants: Plant[] = [
  {
    id: "5",
    name: "Aloe Vera",
    description: "Planta medicinal versátil. Ideal para cuidado de la piel y cicatrización.",
    price: "25.00",
    category: "medicinal",
    imageUrl: "https://cuidateplus.marca.com/sites/default/files/cms/2024-04/aloe-vera.jpg"
  },
  {
    id: "6",
    name: "Manzanilla",
    description: "Calmante natural. Perfecta para tés relajantes y propiedades digestivas.",
    price: "16.50",
    category: "medicinal",
    imageUrl: "https://mamabruja.com/wp-content/uploads/2024/03/ioana-cristiana-Mv9J_UThISA-unsplash-2-scaled.jpg"
  },
  {
    id: "7",
    name: "Eucalipto",
    description: "Propiedades respiratorias. Excelente para aromaterapia y purificación del aire.",
    price: "28.99",
    category: "medicinal",
    imageUrl: "https://cloudfront-us-east-1.images.arcpublishing.com/eluniverso/VFGSA3NHPBHN7GRDIHYTLHFIFI.jpg"
  },
  {
    id: "8",
    name: "Caléndula",
    description: "Antiséptica y curativa. Ideal para cuidado natural de la piel.",
    price: "19.75",
    category: "medicinal",
    imageUrl: "https://sembramos.com.co/wp-content/uploads/2022/12/calendula-planta-pixabay-1200x800.jpg"
  }
];
