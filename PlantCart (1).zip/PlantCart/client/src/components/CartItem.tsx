import { Minus, Plus, Trash2 } from "lucide-react";
import { useDispatch } from "react-redux";
import { updateQuantity, removeFromCart } from "@/store/cartSlice";

interface CartItemProps {
  id: string;
  plant: {
    id: string;
    name: string;
    description: string;
    price: string;
    imageUrl: string;
  };
  quantity: number;
}

export default function CartItem({ id, plant, quantity }: CartItemProps) {
  const dispatch = useDispatch();
  
  const unitPrice = parseFloat(plant.price);
  const totalPrice = unitPrice * quantity;

  const handleIncreaseQuantity = () => {
    dispatch(updateQuantity({ id, quantity: quantity + 1 }));
  };

  const handleDecreaseQuantity = () => {
    if (quantity > 1) {
      dispatch(updateQuantity({ id, quantity: quantity - 1 }));
    }
  };

  const handleRemoveItem = () => {
    dispatch(removeFromCart(id));
  };

  return (
    <div className="border border-gray-200 rounded-lg p-6 flex flex-col md:flex-row items-center gap-6">
      <img 
        src={plant.imageUrl} 
        alt={plant.name} 
        className="w-24 h-24 object-cover rounded-lg"
        loading="lazy"
      />
      
      <div className="flex-1 text-center md:text-left">
        <h3 className="text-lg font-semibold text-gray-900">{plant.name}</h3>
        <p className="text-gray-600 text-sm mt-1">{plant.description}</p>
        <p className="text-forest font-medium mt-2">
          Precio unitario: <span>${unitPrice.toFixed(2)}</span>
        </p>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-3 bg-gray-100 rounded-lg p-2">
          <button 
            className="w-8 h-8 bg-white rounded-md flex items-center justify-center hover:bg-gray-200 transition-colors"
            onClick={handleDecreaseQuantity}
            disabled={quantity <= 1}
          >
            <Minus className="h-4 w-4" />
          </button>
          <span className="font-medium min-w-[2rem] text-center">{quantity}</span>
          <button 
            className="w-8 h-8 bg-white rounded-md flex items-center justify-center hover:bg-gray-200 transition-colors"
            onClick={handleIncreaseQuantity}
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
        
        <div className="text-right">
          <p className="text-lg font-bold text-gray-900">${totalPrice.toFixed(2)}</p>
          <button 
            className="text-red-500 hover:text-red-700 text-sm mt-1 flex items-center"
            onClick={handleRemoveItem}
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Eliminar
          </button>
        </div>
      </div>
    </div>
  );
}
