import { Link, useLocation } from "wouter";
import { ShoppingCart, Menu, Leaf } from "lucide-react";
import { useSelector } from "react-redux";
import type { RootState } from "@/store/store";
import { useState } from "react";

export default function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const cartItemCount = useSelector((state: RootState) => state.cart.totalItems);

  const navItems = [
    { href: "/", label: "Inicio", id: "home" },
    { href: "/products", label: "Productos", id: "products" },
    { href: "/about", label: "Acerca de", id: "about" },
  ];

  const isActive = (href: string) => {
    if (href === "/" && location === "/") return true;
    if (href !== "/" && location.startsWith(href)) return true;
    return false;
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center">
            <Leaf className="text-forest text-2xl mr-3" />
            <span className="text-xl font-bold text-forest">Paradise Nursery</span>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.id}
                href={item.href}
                className={`font-medium transition-colors duration-200 border-b-2 ${
                  isActive(item.href)
                    ? "text-forest border-forest"
                    : "text-gray-700 hover:text-forest border-transparent"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            <Link 
              href="/cart" 
              className="relative p-2 text-gray-700 hover:text-forest transition-colors duration-200"
            >
              <ShoppingCart className="text-xl" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-sand text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </Link>
            
            <button 
              className="md:hidden p-2 text-gray-700 hover:text-forest"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <Menu className="text-xl" />
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.id}
                  href={item.href}
                  className={`px-4 py-2 font-medium transition-colors duration-200 ${
                    isActive(item.href)
                      ? "text-forest bg-sage/10"
                      : "text-gray-700 hover:text-forest hover:bg-gray-50"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
