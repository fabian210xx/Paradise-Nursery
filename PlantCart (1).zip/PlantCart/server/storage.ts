import { type User, type InsertUser, type Plant, type CartItem, type InsertCartItem } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getPlants(): Promise<Plant[]>;
  getPlantsByCategory(category: string): Promise<Plant[]>;
  getPlant(id: string): Promise<Plant | undefined>;
  getCartItems(userId?: string): Promise<(CartItem & { plant: Plant })[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: string, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private plants: Map<string, Plant>;
  private cartItems: Map<string, CartItem>;

  constructor() {
    this.users = new Map();
    this.plants = new Map();
    this.cartItems = new Map();
    
    // Initialize with plant data
    this.initializePlants();
  }

  private initializePlants() {
    const plantsData: Plant[] = [
      // Aromatic Plants
      {
        id: "1",
        name: "Albahaca Fresca",
        description: "Perfecta para cocinar y aromática. Fácil de cuidar en interiores.",
        price: "15.99",
        category: "aromatic",
        imageUrl: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "2",
        name: "Lavanda",
        description: "Aromática y relajante. Ideal para dormitorios y espacios de relajación.",
        price: "22.50",
        category: "aromatic",
        imageUrl: "https://images.unsplash.com/photo-1611909023032-2d6b3134ecba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "3",
        name: "Romero",
        description: "Aromático y culinario. Excelente para la cocina y fácil de mantener.",
        price: "18.75",
        category: "aromatic",
        imageUrl: "https://images.unsplash.com/photo-1572691697247-c0e2cd81fa41?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "4",
        name: "Menta",
        description: "Refrescante y aromática. Perfecta para tés e infusiones caseras.",
        price: "12.99",
        category: "aromatic",
        imageUrl: "https://images.unsplash.com/photo-1628556270448-4d4e4148e1b1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
      },
      // Medicinal Plants
      {
        id: "5",
        name: "Aloe Vera",
        description: "Planta medicinal versátil. Ideal para cuidado de la piel y cicatrización.",
        price: "25.00",
        category: "medicinal",
        imageUrl: "https://cuidateplus.marca.com/sites/default/files/cms/2024-04/aloe-vera.jpg"
      },
      {
        id: "6",
        name: "Manzanilla",
        description: "Calmante natural. Perfecta para tés relajantes y propiedades digestivas.",
        price: "16.50",
        category: "medicinal",
        imageUrl: "https://images.unsplash.com/photo-1635662464106-4b2abfdc5b48?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "7",
        name: "Eucalipto",
        description: "Propiedades respiratorias. Excelente para aromaterapia y purificación del aire.",
        price: "28.99",
        category: "medicinal",
        imageUrl: "https://images.unsplash.com/photo-1541841344-82e2f37492d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
      },
      {
        id: "8",
        name: "Caléndula",
        description: "Antiséptica y curativa. Ideal para cuidado natural de la piel.",
        price: "19.75",
        category: "medicinal",
        imageUrl: "https://images.unsplash.com/photo-1567540045039-3c0030d13e81?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300"
      }
    ];

    plantsData.forEach(plant => {
      this.plants.set(plant.id, plant);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getPlants(): Promise<Plant[]> {
    return Array.from(this.plants.values());
  }

  async getPlantsByCategory(category: string): Promise<Plant[]> {
    return Array.from(this.plants.values()).filter(plant => plant.category === category);
  }

  async getPlant(id: string): Promise<Plant | undefined> {
    return this.plants.get(id);
  }

  async getCartItems(userId?: string): Promise<(CartItem & { plant: Plant })[]> {
    const items = Array.from(this.cartItems.values());
    const result = [];
    
    for (const item of items) {
      const plant = this.plants.get(item.plantId);
      if (plant) {
        result.push({ ...item, plant });
      }
    }
    
    return result;
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists in cart
    const existingItem = Array.from(this.cartItems.values())
      .find(item => item.plantId === insertItem.plantId);
    
    if (existingItem) {
      // Update quantity
      existingItem.quantity += insertItem.quantity || 1;
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    } else {
      // Add new item
      const id = randomUUID();
      const item: CartItem = { 
        id,
        plantId: insertItem.plantId,
        quantity: insertItem.quantity || 1,
        userId: insertItem.userId || null
      };
      this.cartItems.set(id, item);
      return item;
    }
  }

  async updateCartItemQuantity(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (item) {
      item.quantity = quantity;
      this.cartItems.set(id, item);
      return item;
    }
    return undefined;
  }

  async removeCartItem(id: string): Promise<boolean> {
    return this.cartItems.delete(id);
  }
}

export const storage = new MemStorage();
