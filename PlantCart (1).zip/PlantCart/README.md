# Paradise Nursery - Aplicación de Compras

Una aplicación web de carrito de compras para Paradise Nursery, una tienda en línea especializada en plantas aromáticas y medicinales.

## Características

- **Página de Inicio**: Presentación de la empresa con imagen principal
- **Página de Productos**: Catálogo de 8 plantas únicas (4 aromáticas y 4 medicinales)
- **Carrito de Compras**: Funcionalidad completa para agregar/quitar productos y gestionar cantidades
- **Navegación**: Header con contador de carrito y navegación entre páginas
- **Página Acerca de**: Información detallada de la empresa

## Tecnologías Utilizadas

- **React**: Framework principal para la interfaz de usuario
- **Redux**: Gestión del estado global del carrito
- **Tailwind CSS**: Estilos y diseño responsivo
- **JavaScript/TypeScript**: Lenguaje de programación
- **Wouter**: Enrutamiento del lado del cliente

## Plantas Disponibles

### Plantas Aromáticas
1. Albahaca Fresca - $15.99
2. Lavanda - $22.50
3. Romero - $18.75
4. Menta - $12.99

### Plantas Medicinales
1. Aloe Vera - $25.00
2. Manzanilla - $16.50
3. Eucalipto - $28.99
4. Caléndula - $19.75

## Instalación y Uso

1. Clonar el repositorio
2. Instalar dependencias: `npm install`
3. Ejecutar en modo desarrollo: `npm run dev`
4. Para GitHub Pages: `npm run build` y subir la carpeta `dist`

## Despliegue en GitHub Pages

Esta aplicación está optimizada para funcionar en GitHub Pages sin necesidad de servidor backend.

## Estructura del Proyecto

```
client/
├── src/
│   ├── components/     # Componentes reutilizables
│   ├── pages/         # Páginas principales
│   ├── store/         # Configuración de Redux
│   ├── data/          # Datos de productos
│   └── App.tsx        # Componente principal
└── public/            # Archivos estáticos
```

## Autor

Proyecto creado para el curso final de desarrollo frontend con JavaScript y React.